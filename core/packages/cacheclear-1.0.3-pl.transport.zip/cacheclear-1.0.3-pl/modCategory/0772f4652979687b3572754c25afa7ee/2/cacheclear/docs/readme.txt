
CacheClear

Deletes all files in the core/cache directory

Author: Bob Ray <http://bobsguides.com>
Copyright 2012

Official Documentation: http://bobsguides.com/cache-clear-tutorial.html

Bugs and Feature Requests: https://github.com/BobRay/CacheClear

Questions: http://forums.modx.com

Created by MyComponent
