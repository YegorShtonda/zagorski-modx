-------------------------------
Plugins: LogPageNotFound
Snippets: PageNotFoundLogReport
-------------------------------
Author: Bob Ray <http://bobsguides.com>

Official Documentation: http://bobsguides.com/logpagenotfound-tutorial.html
Bugs and Feature Requests: https://github.com/BobRay/LogPageNotFound
Questions: http://forums.modx.com
