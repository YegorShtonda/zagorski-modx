<?php

$_lang['autoredirector_prop_limit'] = 'Počet pravidel na stránku.';
$_lang['autoredirector_prop_outputSeparator'] = 'Řetězec pro oddělení řádků.';
$_lang['autoredirector_prop_sortBy'] = 'Pole pro seřazení.';
$_lang['autoredirector_prop_sortDir'] = 'Směr řazení.';
$_lang['autoredirector_prop_tpl'] = 'Chunk bude použit pro každý řádek pravidel.';
$_lang['autoredirector_prop_toPlaceholder'] = 'Pokud je nastaven, výstup bude nastaven do tohoto placeholderu namísto zobrazení.';
$_lang['autoredirector_res_id'] = 'Resource';
$_lang['autoredirector_uri'] = 'URI';
