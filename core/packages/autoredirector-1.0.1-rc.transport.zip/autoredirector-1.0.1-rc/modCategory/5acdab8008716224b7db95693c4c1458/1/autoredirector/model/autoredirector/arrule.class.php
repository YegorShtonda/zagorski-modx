<?php
class arRule extends xPDOSimpleObject {}