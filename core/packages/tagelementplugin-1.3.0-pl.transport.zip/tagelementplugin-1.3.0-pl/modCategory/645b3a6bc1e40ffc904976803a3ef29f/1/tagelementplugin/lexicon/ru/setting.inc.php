<?php

$_lang['tagelementplugin_main'] = 'Основные';

$_lang['setting_tagelementplugin_quick_editor_keys'] = 'Открыть окно быстрого редактирования';
$_lang['setting_tagelementplugin_quick_editor_keys_desc'] = 'Сочетание клавиш для открытия элемента в диалоге быстрого редактирования. Можно указывать цифровой код клавиши.';
$_lang['setting_tagelementplugin_element_editor_keys'] = 'Переход на страницу элемента';
$_lang['setting_tagelementplugin_element_editor_keys_desc'] = 'Сочетание клавиш для перехода на страницу элемента. Можно указывать цифровой код клавиши.';
$_lang['setting_tagelementplugin_element_prop_keys'] = 'Открыть окно параметров элемента';
$_lang['setting_tagelementplugin_element_prop_keys_desc'] = 'Сочетание клавиш для диалога параметров элемента. Можно указывать цифровой код клавиши.';
$_lang['setting_tagelementplugin_quick_chunk_editor_keys'] = 'Открыть окно редактирования чанка';
$_lang['setting_tagelementplugin_quick_chunk_editor_keys_desc'] = 'Сочетание клавиш для открытия чанка в диалоге быстрого редактирования. Можно указывать цифровой код клавиши.';
$_lang['setting_tagelementplugin_chunk_editor_keys'] = 'Переход на страницу чанка';
$_lang['setting_tagelementplugin_chunk_editor_keys_desc'] = 'Сочетание клавиш для перехода на страницу чанка. Можно указывать цифровой код клавиши.';