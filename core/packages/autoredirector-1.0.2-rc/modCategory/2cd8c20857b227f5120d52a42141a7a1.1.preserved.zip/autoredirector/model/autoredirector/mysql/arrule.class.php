<?php
require_once (dirname(__DIR__) . '/arrule.class.php');
class arRule_mysql extends arRule {}